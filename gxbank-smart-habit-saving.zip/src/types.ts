export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  icon: string;
  color: string;
  deadline?: string;
}

export interface CategoryBudget {
  monthly: number;
  daily: number;
  emoji: string;
}

export interface BudgetTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  categories: {
    food: CategoryBudget;
    entertainment: CategoryBudget;
    shopping: CategoryBudget;
    transport: CategoryBudget;
    misc: CategoryBudget;
  };
  totalSafeDaily: number;
  estimatedSavingsRange: string;
  impactInsight: string;
}

export interface SmartHabit {
  id: string;
  interestId: string;
  name: string;
  suggestion: string;
  dailyTarget: number;
  emotionalPrompt: string;
  icon: any; // Lucide icon or string
}

export interface Interest {
  id: string;
  name: string;
  icon: string;
}

export interface UserState {
  balance: number;
  monthlyIncome: number;
  dailyBudget: number;
  todaySpent: number;
  categorySpending: {
    food: number;
    entertainment: number;
    shopping: number;
    transport: number;
    misc: number;
  };
  totalSaved: number;
  streak: number;
  goals: SavingsGoal[];
  activeTemplate: string;
  autoSaveEnabled: boolean;
  roundUpEnabled: boolean;
  selectedInterests: string[];
  smartHabits: SmartHabit[];
  customInterest: string;
}

export type View = 'splash' | 'setup' | 'setup-interests' | 'setup-budget' | 'dashboard' | 'goals' | 'savings' | 'summary' | 'rewards' | 'alert';
