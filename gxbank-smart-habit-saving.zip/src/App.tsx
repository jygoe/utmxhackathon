/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet, 
  Target, 
  TrendingUp, 
  Award, 
  Plus, 
  ChevronRight, 
  Bell, 
  Coffee, 
  ShoppingBag, 
  Music, 
  Truck,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Coins,
  Lock,
  History,
  Gift,
  Zap,
  Gamepad2,
  Heart,
  Plane,
  Camera,
  Shirt,
  Utensils,
  Book,
  Laptop
} from 'lucide-react';
import { View, UserState, SavingsGoal, BudgetTemplate, Interest, SmartHabit } from './types';

// Constants & Mock Data
const BUDGET_TEMPLATES: BudgetTemplate[] = [
  { 
    id: 'balanced', 
    name: 'Balanced Lifestyle', 
    description: 'Flexible spending with healthy savings balance',
    icon: '⚖️',
    categories: {
      food: { monthly: 600, daily: 20, emoji: '🍔' },
      entertainment: { monthly: 300, daily: 10, emoji: '🎮' },
      shopping: { monthly: 200, daily: 6, emoji: '🛍️' },
      transport: { monthly: 150, daily: 5, emoji: '🚆' },
      misc: { monthly: 150, daily: 5, emoji: '💡' }
    },
    totalSafeDaily: 46,
    estimatedSavingsRange: 'RM 300 – RM 450',
    impactInsight: 'Optimal flexibility for moderate savers.'
  },
  { 
    id: 'minimal', 
    name: 'Minimal Saver', 
    description: 'Maximize savings, reduce non-essential spending',
    icon: '🧘',
    categories: {
      food: { monthly: 450, daily: 15, emoji: '🍔' },
      entertainment: { monthly: 150, daily: 5, emoji: '🎮' },
      shopping: { monthly: 60, daily: 2, emoji: '🛍️' },
      transport: { monthly: 120, daily: 4, emoji: '🚆' },
      misc: { monthly: 90, daily: 3, emoji: '💡' }
    },
    totalSafeDaily: 29,
    estimatedSavingsRange: 'RM 600+',
    impactInsight: 'Highest savings potential, strictest limits.'
  },
  { 
    id: 'social', 
    name: 'Social Explorer', 
    description: 'Higher entertainment & social flexibility',
    icon: '🎉',
    categories: {
      food: { monthly: 750, daily: 25, emoji: '🍔' },
      entertainment: { monthly: 600, daily: 20, emoji: '🎮' },
      shopping: { monthly: 450, daily: 15, emoji: '🛍️' },
      transport: { monthly: 200, daily: 7, emoji: '🚆' },
      misc: { monthly: 200, daily: 7, emoji: '💡' }
    },
    totalSafeDaily: 74,
    estimatedSavingsRange: 'RM 150 – RM 250',
    impactInsight: 'Fun-focused but slower savings growth.'
  },
  { 
    id: 'student', 
    name: 'Student Survival', 
    description: 'Strict essential-focused budgeting',
    icon: '🎓',
    categories: {
      food: { monthly: 300, daily: 10, emoji: '🍔' },
      entertainment: { monthly: 60, daily: 2, emoji: '🎮' },
      shopping: { monthly: 60, daily: 2, emoji: '🛍️' },
      transport: { monthly: 90, daily: 3, emoji: '🚆' },
      misc: { monthly: 60, daily: 2, emoji: '💡' }
    },
    totalSafeDaily: 19,
    estimatedSavingsRange: 'RM 100 – RM 200',
    impactInsight: 'Survive on campus while building a small nest.'
  },
  { 
    id: 'shopping', 
    name: 'Shopaholic Control', 
    description: 'Controlled spending for online shopping habits',
    icon: '🛍️',
    categories: {
      food: { monthly: 500, daily: 17, emoji: '🍔' },
      entertainment: { monthly: 150, daily: 5, emoji: '🎮' },
      shopping: { monthly: 900, daily: 30, emoji: '🛍️' },
      transport: { monthly: 150, daily: 5, emoji: '🚆' },
      misc: { monthly: 150, daily: 5, emoji: '💡' }
    },
    totalSafeDaily: 62,
    estimatedSavingsRange: 'RM 200 – RM 350',
    impactInsight: 'Keep your lifestyle while curbing excess.'
  }
];

const INTERESTS: Interest[] = [
  { id: 'kpop', name: 'K-POP', icon: '🎵' },
  { id: 'coffee', name: 'Coffee', icon: '☕' },
  { id: 'pets', name: 'Pets', icon: '🐾' },
  { id: 'gaming', name: 'Gaming', icon: '🎮' },
  { id: 'travel', name: 'Travel', icon: '✈️' },
  { id: 'fitness', name: 'Fitness', icon: '💪' },
  { id: 'fashion', name: 'Fashion', icon: '👗' },
  { id: 'food', name: 'Food Delivery', icon: '🍕' },
  { id: 'concerts', name: 'Concerts', icon: '🎫' },
  { id: 'photography', name: 'Photography', icon: '📷' },
  { id: 'gadgets', name: 'Gadgets', icon: '📱' },
  { id: 'anime', name: 'Anime', icon: '🏮' },
  { id: 'books', name: 'Books', icon: '📚' },
];

const HABIT_CONFIGS: Record<string, any> = {
  kpop: { icon: Music, name: 'Concert Fund', habit: 'Daily light saving', emoji: '🎫' },
  coffee: { icon: Coffee, name: 'Barista Mode', habit: 'Skip one brew', emoji: '☕' },
  pets: { icon: Heart, name: 'Pet Care', habit: 'Emergency fund contribution', emoji: '🐾' },
  gaming: { icon: Gamepad2, name: 'Game Loot', habit: 'Reduce in-game buys', emoji: '🎮' },
  travel: { icon: Plane, name: 'Jetsetter', habit: 'Trip contribution', emoji: '✈️' },
  fitness: { icon: Zap, name: 'Fit Saver', habit: 'Workout reward', emoji: '💪' },
  fashion: { icon: Shirt, name: 'Style Fund', habit: 'Delay fashion haul', emoji: '👗' },
  food: { icon: Utensils, name: 'Home Chef', habit: 'Cook instead of delivery', emoji: '🍳' },
  photography: { icon: Camera, name: 'Lens Fund', habit: 'Pro gear savings', emoji: '📷' },
  gadgets: { icon: Laptop, name: 'Techie', habit: 'Next upgrade fund', emoji: '💻' },
  books: { icon: Book, name: 'Library Mode', habit: 'Bookworm savings', emoji: '📚' },
  custom: { icon: Target, name: 'Smart Goal', habit: 'General saving', emoji: '✨' },
};

export default function App() {
  const [view, setView] = useState<View>('splash');
  const [user, setUser] = useState<UserState>({
    balance: 2450.50,
    monthlyIncome: 3000,
    dailyBudget: 46,
    todaySpent: 28.00,
    categorySpending: {
      food: 12.00,
      entertainment: 5.00,
      shopping: 8.00,
      transport: 3.00,
      misc: 0.00
    },
    totalSaved: 450.00,
    streak: 12,
    goals: [
      { id: '1', name: 'Japan Trip', targetAmount: 5000, currentAmount: 1200, icon: '✈️', color: 'from-purple-500 to-indigo-500' },
      { id: '2', name: 'New Laptop', targetAmount: 3500, currentAmount: 850, icon: '💻', color: 'from-pink-500 to-rose-500' },
    ],
    activeTemplate: 'balanced',
    autoSaveEnabled: true,
    roundUpEnabled: true,
    selectedInterests: ['coffee'],
    smartHabits: [
      { 
        id: '1', 
        interestId: 'coffee', 
        name: 'Barista Mode', 
        suggestion: 'Skipping 1 coffee this week could save RM18 toward your travel fund.',
        dailyTarget: 3,
        emotionalPrompt: 'Your future self will appreciate this. ☕',
        icon: Coffee
      }
    ],
    customInterest: '',
  });

  const [notification, setNotification] = useState<string | null>(null);

  // Transitions for screens - Snappier
  const screenVariants = {
    initial: { opacity: 0, x: 10 },
    animate: { opacity: 1, x: 0, transition: { duration: 0.25, ease: "easeOut" } },
    exit: { opacity: 0, x: -10, transition: { duration: 0.2, ease: "easeIn" } },
  };

  const handleStart = () => setView('setup');
  const handleSetupComplete = (income: number) => {
    setUser({ ...user, monthlyIncome: income });
    setView('setup-budget');
  };

  const handleBudgetComplete = (templateId: string) => {
    const selectedTemplate = BUDGET_TEMPLATES.find(t => t.id === templateId) || BUDGET_TEMPLATES[0];
    setUser({ ...user, activeTemplate: templateId, dailyBudget: selectedTemplate.totalSafeDaily });
    setView('setup-interests');
  };

  const handleInterestsComplete = (interests: string[], custom: string) => {
    // Generate smart habits based on interests
    const generatedHabits: SmartHabit[] = interests.map((id, index) => {
      const config = HABIT_CONFIGS[id] || HABIT_CONFIGS.custom;
      const dailyTarget = [1, 3, 5][index % 3]; // RM1, RM3, or RM5
      
      const suggestions: Record<string, string> = {
        kpop: `Save RM${dailyTarget} daily for your next concert ticket.`,
        coffee: `Skipping 1 coffee this week could save RM${dailyTarget * 7} toward your goals.`,
        pets: `Save RM${dailyTarget} daily to build a pet emergency fund.`,
        gaming: `Reducing one in-game purchase weekly could save RM${dailyTarget * 10} monthly.`,
        travel: `You're only RM${dailyTarget * 5} away from staying on track for your Japan trip.`,
        food: `Cooking once this week could add RM${dailyTarget * 8} to your savings.`,
        custom: `Saving RM${dailyTarget} daily helps reach "${custom}" faster.`,
      };

      const prompts = [
        "Tiny savings still count 💜",
        "Your future self will appreciate this.",
        "A small step today = bigger freedom later.",
        "You're getting closer ✨"
      ];

      return {
        id: Math.random().toString(36).substr(2, 9),
        interestId: id,
        name: config.name,
        suggestion: suggestions[id] || suggestions.custom,
        dailyTarget: dailyTarget,
        emotionalPrompt: prompts[Math.floor(Math.random() * prompts.length)],
        icon: config.icon
      };
    });

    setUser({ ...user, selectedInterests: interests, customInterest: custom, smartHabits: generatedHabits });
    setView('dashboard');
  };

  // Shared Components
  const BottomNav = ({ activeView, setView }: { activeView: View, setView: (v: View) => void }) => (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-[#120b2e]/80 backdrop-blur-2xl border-t border-white/5 px-6 py-5 flex justify-between items-center z-50">
      <NavItem icon={Wallet} label="Home" active={activeView === 'dashboard'} onClick={() => setView('dashboard')} />
      <NavItem icon={Coins} label="Savings" active={activeView === 'savings'} onClick={() => setView('savings')} />
      <NavItem icon={Target} label="Goals" active={activeView === 'goals'} onClick={() => setView('goals')} />
      <NavItem icon={TrendingUp} label="Summary" active={activeView === 'summary'} onClick={() => setView('summary')} />
      <NavItem icon={Award} label="Rewards" active={activeView === 'rewards'} onClick={() => setView('rewards')} />
    </nav>
  );

  const NavItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 transition-all duration-300 ${active ? 'text-gx-pink scale-110 drop-shadow-[0_0_8px_rgba(255,0,255,0.4)]' : 'text-gray-500 hover:text-gray-300'}`}>
      <Icon size={20} strokeWidth={active ? 3 : 2} />
      <span className="text-[10px] font-black uppercase tracking-tighter">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-[#0a061a] font-sans text-white flex justify-center items-center selection:bg-gx-pink/30 p-4 lg:p-0 relative antialiased">
      
      {/* Ambient Glows - Subtler */}
      <div className="ambient-glow w-[600px] h-[600px] bg-indigo-900/20 -top-40 -left-40"></div>
      <div className="ambient-glow w-[500px] h-[500px] bg-purple-900/10 -bottom-20 -right-20"></div>
      <div className="ambient-glow w-[400px] h-[400px] bg-gx-orange top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10"></div>

      {/* High Density Viewport - Only visible on LG screens and above */}
      <div className="hidden lg:grid w-full h-full max-w-[1280px] grid-cols-[300px_1fr_300px] gap-6 p-6 box-border items-start relative z-10">
        
        {/* Left Aside */}
        <aside className="space-y-6">
          <div className="gx-glass-card p-5">
            <div className="pill pill-purple">Automated Savings</div>
            <h3 className="text-base font-black mb-1">Micro-Saving Log</h3>
            <p className="text-[11px] text-gray-400 mb-4 font-medium">Yesterday's quiet wins</p>
            <div className="space-y-3">
              <div className="flex justify-between text-xs font-medium">
                <span className="text-gray-300">Grab Round-up</span>
                <span className="text-emerald-400 font-bold">+RM 0.40</span>
              </div>
              <div className="flex justify-between text-xs font-medium">
                <span className="text-gray-300">Daily Budget Leftover</span>
                <span className="text-emerald-400 font-bold">+RM 6.00</span>
              </div>
              <div className="flex justify-between text-xs font-medium">
                <span className="text-gray-300">No-Shopping Streak</span>
                <span className="text-emerald-400 font-bold">+RM 1.00</span>
              </div>
            </div>
            <div className="mt-5 pt-5 border-t border-white/5">
              <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest">Total saved automatically</p>
              <h2 className="text-2xl font-black bg-gradient-to-r from-gx-pink to-purple-400 bg-clip-text text-transparent mt-1">RM {user.totalSaved.toFixed(2)}</h2>
            </div>
          </div>

          <div className="gx-glass-card p-5">
            <div className="pill pill-orange">Goal Tracker</div>
            <h3 className="text-base font-black mb-1">Japan Trip Fund</h3>
            <div className="h-2 bg-white/5 rounded-full my-3 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-gx-orange to-amber-400 rounded-full shadow-[0_0_10px_rgba(249,115,22,0.4)]" style={{ width: '65%' }}></div>
            </div>
            <p className="text-[11px] text-gray-400 font-black uppercase tracking-tighter">65% • 2 months ahead</p>
            <p className="text-xs italic mt-4 text-gray-400 leading-relaxed font-medium">"That RM8 saved today is one step closer to Tokyo! 🗼"</p>
          </div>
        </aside>

        {/* Center - Mobile Frame */}
        <main className="flex justify-center">
          <div className="w-[375px] h-[780px] bg-gx-purple-dark rounded-[44px] border-[10px] border-black shadow-2xl relative overflow-hidden flex flex-col scale-90 xxl:scale-100">
            <AnimatePresence mode="popLayout">
              {view === 'splash' && (
                <motion.div key="splash" {...screenVariants} className="flex-1 flex flex-col">
                  <SplashScreen onStart={handleStart} />
                </motion.div>
              )}

              {view === 'setup' && (
                <motion.div key="setup" {...screenVariants} className="flex-1 flex flex-col">
                  <SetupScreen onComplete={handleSetupComplete} />
                </motion.div>
              )}

              {view === 'setup-budget' && (
                <motion.div key="setup-budget" {...screenVariants} className="flex-1 flex flex-col">
                  <SetupBudgetScreen onComplete={handleBudgetComplete} />
                </motion.div>
              )}

              {view === 'setup-interests' && (
                <motion.div key="setup-interests" {...screenVariants} className="flex-1 flex flex-col">
                  <InterestSelectionScreen onComplete={handleInterestsComplete} />
                </motion.div>
              )}

              {(view === 'dashboard' || view === 'goals' || view === 'savings' || view === 'summary' || view === 'rewards') && (
                <motion.div key="authenticated" {...screenVariants} className="flex-1 flex flex-col pb-24">
                  {/* Header - Refined */}
                  <header className="px-6 pt-10 pb-8 bg-gx-purple-dark border-b border-white/5 relative z-20">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-3xl font-black italic tracking-tighter text-gx-pink drop-shadow-[0_0_15px_rgba(255,0,255,0.3)]">GX</span>
                      <button 
                        onClick={() => setView('alert')}
                        className="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center relative backdrop-blur-sm hover:bg-white/10 active:scale-95 transition-all"
                      >
                        <Bell size={20} className="text-white" />
                        <span className="absolute top-3 right-3 w-2 h-2 bg-gx-pink rounded-full shadow-[0_0_8px_rgba(255,0,255,0.8)] border border-gx-purple-dark"></span>
                      </button>
                    </div>
                    <div>
                      <p className="text-[11px] text-gray-400 font-black uppercase tracking-[3px] mb-1">Total Available Balance</p>
                      <h1 className="text-4xl font-black text-white tracking-tighter italic">RM {user.balance.toLocaleString()}</h1>
                    </div>
                  </header>

                  <main className="flex-1 overflow-y-auto px-5 bg-gx-purple-dark scrollbar-hide">
                    <AnimatePresence mode="popLayout">
                      {view === 'dashboard' && (
                        <motion.div key="dash" {...screenVariants}>
                          <DashboardView user={user} setView={setView} />
                        </motion.div>
                      )}
                      {view === 'goals' && (
                        <motion.div key="goals" {...screenVariants}>
                          <GoalsView user={user} />
                        </motion.div>
                      )}
                      {view === 'savings' && (
                        <motion.div key="savings" {...screenVariants}>
                          <SavingsView user={user} setUser={setUser} setView={setView} />
                        </motion.div>
                      )}
                      {view === 'summary' && (
                        <motion.div key="summary" {...screenVariants}>
                          <SummaryView user={user} />
                        </motion.div>
                      )}
                      {view === 'rewards' && (
                        <motion.div key="rewards" {...screenVariants}>
                          <RewardsView user={user} />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </main>

                  <BottomNav activeView={view} setView={setView} />
                </motion.div>
              )}

              {view === 'alert' && (
                <motion.div key="alert" {...screenVariants} className="flex-1 flex flex-col">
                  <AlertScreen onBack={() => setView('dashboard')} />
                </motion.div>
              )}
            </AnimatePresence>

            {/* AI Notification Overlay inside phone */}
            <AnimatePresence>
              {notification && (
                <motion.div 
                  initial={{ y: 50, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 50, opacity: 0 }}
                  className="absolute bottom-24 left-4 right-4 bg-[#120b2e]/95 text-white p-4 rounded-3xl shadow-xl flex items-center gap-3 z-[60] backdrop-blur-md border border-white/10"
                >
                  <Zap size={18} className="text-gx-pink shrink-0" />
                  <p className="text-[11px] font-bold leading-tight">{notification}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>

        {/* Right Aside */}
        <aside className="space-y-6">
          <div className="gx-glass-card p-5">
            <div className="pill pill-purple">Behavioral Insights</div>
            <h3 className="text-base font-black mb-4">Shopping Trends</h3>
            <div className="flex items-end h-[60px] gap-2 mb-4">
              <div className="flex-1 h-[40%] bg-white/5 rounded-sm"></div>
              <div className="flex-1 h-[60%] bg-white/5 rounded-sm"></div>
              <div className="flex-1 h-[95%] bg-gx-pink shadow-[0_0_15px_rgba(255,0,255,0.4)] rounded-sm"></div>
              <div className="flex-1 h-[35%] bg-white/5 rounded-sm"></div>
              <div className="flex-1 h-[25%] bg-white/5 rounded-sm"></div>
            </div>
            <p className="text-xs leading-relaxed text-gray-400 font-medium">
              "You tend to spend 38% more on <b className="text-white">Wednesday nights</b> during exam weeks. We've got your back Ahmad!"
            </p>
          </div>

          <div className="gx-glass-card p-5">
            <div className="pill pill-orange">Consistency Rewards</div>
            <div className="flex items-center gap-4 mt-2">
              <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-amber-600 rounded-2xl flex items-center justify-center text-white font-black text-xl shadow-[0_0_15px_rgba(245,158,11,0.3)] border border-white/20">
                12
              </div>
              <div>
                <h4 className="font-black text-sm text-white">Day Streak!</h4>
                <p className="text-[10px] text-gray-400 font-black uppercase tracking-tight">Saving daily like a pro</p>
              </div>
            </div>
            <div className="mt-5 p-4 bg-orange-500/5 rounded-2xl border border-dashed border-orange-500/20">
              <p className="text-xs text-orange-200">
                <b className="text-orange-400">Next Reward:</b> RM5 Shopee Voucher for 15-day streak.
              </p>
            </div>
          </div>

          <div className="gx-glass-card bg-gradient-to-br from-[#1e1b4b] to-[#312e81] p-5 border-0 shadow-indigo-500/20">
            <h3 className="text-sm font-black mb-1">Smart Habit Savings</h3>
            <p className="text-[10px] text-gray-400 mb-5 font-black uppercase tracking-widest">Small habits. Bigger future.</p>
            <button className="gx-neon-button w-full py-3 text-[11px] uppercase tracking-wider">
              Get Started
            </button>
          </div>
        </aside>

      </div>

      {/* Standard Mobile View - Visible only below LG (fallback/orig) */}
      <div className="lg:hidden w-full max-w-md bg-gx-purple-dark min-h-screen relative overflow-hidden flex flex-col">
        <AnimatePresence mode="popLayout">
          {/* ... (splas, setup etc) */}
          {view === 'splash' && (
            <div key="splash" className="flex-1 flex flex-col">
              <SplashScreen onStart={handleStart} />
            </div>
          )}

          {view === 'setup' && (
            <div key="setup" className="flex-1 flex flex-col">
              <SetupScreen onComplete={handleSetupComplete} />
            </div>
          )}

          {view === 'setup-budget' && (
            <div key="setup-budget" className="flex-1 flex flex-col">
              <SetupBudgetScreen onComplete={handleBudgetComplete} />
            </div>
          )}

          {view === 'setup-interests' && (
            <div key="setup-interests" className="flex-1 flex flex-col">
              <InterestSelectionScreen onComplete={handleInterestsComplete} />
            </div>
          )}

          {(view === 'dashboard' || view === 'goals' || view === 'savings' || view === 'summary' || view === 'rewards') && (
            <div key="authenticated" className="flex-1 flex flex-col pb-24">
              <header className="px-6 pt-10 pb-8 bg-gx-purple-dark border-b border-white/5">
                <div className="flex justify-between items-center mb-6">
                  <span className="text-3xl font-black italic tracking-tighter text-gx-pink drop-shadow-[0_0_15px_rgba(255,0,255,0.3)]">GX</span>
                  <button 
                    onClick={() => setView('alert')}
                    className="w-11 h-11 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center relative backdrop-blur-sm shadow-xl"
                  >
                    <Bell size={20} className="text-white" />
                    <span className="absolute top-3 right-3 w-2 h-2 bg-gx-pink rounded-full shadow-[0_0_8px_rgba(255,0,255,0.8)] border border-gx-purple-dark"></span>
                  </button>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400 font-black uppercase tracking-[3px] mb-1">Total Available Balance</p>
                  <h1 className="text-4xl font-black text-white tracking-tighter italic">RM {user.balance.toLocaleString()}</h1>
                </div>
              </header>

              <main className="flex-1 overflow-y-auto px-6 bg-gx-purple-dark scrollbar-hide">
                <AnimatePresence mode="popLayout">
                  {view === 'dashboard' && (
                    <motion.div key="dash-mob" {...screenVariants}>
                      <DashboardView user={user} setView={setView} />
                    </motion.div>
                  )}
                  {view === 'goals' && (
                    <motion.div key="goals-mob" {...screenVariants}>
                      <GoalsView user={user} />
                    </motion.div>
                  )}
                  {view === 'savings' && (
                    <motion.div key="savings-mob" {...screenVariants}>
                      <SavingsView user={user} setUser={setUser} setView={setView} />
                    </motion.div>
                  )}
                  {view === 'summary' && (
                    <motion.div key="summary-mob" {...screenVariants}>
                      <SummaryView user={user} />
                    </motion.div>
                  )}
                  {view === 'rewards' && (
                    <motion.div key="rewards-mob" {...screenVariants}>
                      <RewardsView user={user} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </main>

              <BottomNav activeView={view} setView={setView} />
            </div>
          )}

          {view === 'alert' && (
            <div key="alert" className="flex-1 flex flex-col">
              <AlertScreen onBack={() => setView('dashboard')} />
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// --- SUB-SCREENS ---

function SplashScreen({ onStart }: { onStart: () => void }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 bg-gx-purple-dark relative overflow-hidden">
      <div className="ambient-glow w-64 h-64 bg-gx-pink/10 -top-20 -left-20 blur-3xl"></div>
      
      <motion.div
        animate={{ 
          scale: [1, 1.05, 1],
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="w-24 h-24 mb-10 rounded-[32px] bg-white p-0.5 shadow-[0_20px_50px_rgba(0,0,0,0.3)]"
      >
        <div className="w-full h-full bg-white rounded-[31px] flex items-center justify-center overflow-hidden">
          <span className="text-4xl font-black text-gx-purple-dark italic tracking-tighter">GX</span>
        </div>
      </motion.div>
      
      <h1 className="text-4xl font-black text-center mb-4 tracking-tighter text-white">Passion Saving</h1>
      <p className="text-gray-400 text-center mb-16 text-lg font-medium leading-relaxed">Turn what you love into <br/> achievable habits.</p>
      
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onStart}
        className="gx-neon-button w-full py-6 flex items-center justify-center gap-3 text-sm tracking-widest uppercase font-black"
      >
        Secure start <ArrowRight size={20} />
      </motion.button>
    </div>
  );
}

function InterestSelectionScreen({ onComplete }: { onComplete: (interests: string[], custom: string) => void }) {
  const [selected, setSelected] = useState<string[]>([]);
  const [custom, setCustom] = useState('');

  const toggleInterest = (id: string) => {
    if (selected.includes(id)) {
      setSelected(selected.filter(i => i !== id));
    } else {
      if (selected.length < 3) {
        setSelected([...selected, id]);
      }
    }
  };

  return (
    <div className="flex-1 flex flex-col p-6 bg-gx-purple-dark relative overflow-hidden">
      <div className="ambient-glow w-64 h-64 bg-gx-pink/5 -top-20 -right-20"></div>
      
      <h2 className="text-3xl font-black mb-2 mt-4 text-white tracking-tight">What do you love?</h2>
      <p className="text-gray-400 mb-10 font-medium leading-relaxed">We'll build saving habits around your passions. (Pick up to 3)</p>

      <div className="flex-1 overflow-y-auto pr-2 space-y-8 relative z-10 scrollbar-hide">
        <div className="grid grid-cols-2 gap-4">
          {INTERESTS.map((interest) => (
            <motion.button
              key={interest.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => toggleInterest(interest.id)}
              className={`p-6 rounded-[32px] border transition-all flex flex-col items-center gap-3 ${
                selected.includes(interest.id)
                  ? 'border-gx-pink bg-white shadow-2xl'
                  : 'border-white/5 bg-gx-purple-mid hover:border-white/10'
              }`}
            >
              <span className="text-4xl">{interest.icon}</span>
              <span className={`text-[13px] font-black tracking-tight ${selected.includes(interest.id) ? 'text-gx-purple-dark' : 'text-white'}`}>
                {interest.name}
              </span>
            </motion.button>
          ))}
        </div>

        <div className="pt-4">
          <label className="text-[11px] font-black text-gray-500 uppercase tracking-[2px] mb-4 block">Or a custom goal?</label>
          <input 
            type="text" 
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            placeholder="e.g. Save for a new camera"
            className="w-full bg-gx-purple-mid border border-white/10 p-6 rounded-[24px] outline-none focus:border-gx-pink/50 text-base text-white transition-all shadow-inner"
          />
        </div>
      </div>

      <div className="pt-8 relative z-10">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => onComplete(selected.length > 0 ? selected : (custom ? ['custom'] : []), custom)}
          disabled={selected.length === 0 && !custom}
          className="gx-neon-button w-full py-6 text-sm tracking-widest uppercase font-black disabled:opacity-20"
        >
          Generate my habits
        </motion.button>
      </div>
    </div>
  );
}

function SetupScreen({ onComplete }: { onComplete: (income: number) => void }) {
  const [income, setIncome] = useState(3000);

  return (
    <div className="flex-1 flex flex-col p-6 bg-gx-purple-dark relative overflow-hidden">
      <div className="ambient-glow w-64 h-64 bg-gx-pink/5 -top-20 -right-20 blur-3xl"></div>
      
      <h2 className="text-3xl font-black mb-3 mt-8 text-white tracking-tight">Monthly flow</h2>
      <p className="text-gray-400 mb-12 font-medium leading-relaxed">Let's start with your available funds.</p>

      <div className="space-y-10 relative z-10 flex-1 flex flex-col justify-center">
        <div>
          <label className="text-[12px] font-black text-gray-500 uppercase tracking-[3px] mb-6 block text-center">Estimated monthly income</label>
          <div className="flex items-center gap-3 bg-gx-purple-mid p-10 rounded-[44px] border border-white/5 focus-within:border-gx-pink/50 transition-all shadow-2xl">
            <span className="text-4xl font-black text-gx-pink italic mr-2 drop-shadow-[0_0_10px_rgba(255,0,255,0.2)]">RM</span>
            <input 
              type="number" 
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
              className="text-6xl font-black w-full bg-transparent outline-none focus:ring-0 text-white tracking-tighter"
              placeholder="0.00"
            />
          </div>
          <p className="text-center text-gray-500 text-[11px] mt-6 font-medium italic">This helps us calculate your daily safe-to-spend limit.</p>
        </div>
      </div>

      <div className="mt-auto pt-10 relative z-10">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => onComplete(income)}
          className="gx-neon-button w-full py-6 text-sm tracking-widest uppercase flex items-center justify-center gap-3 font-black"
        >
          Choose lifestyle <ArrowRight size={20} />
        </motion.button>
      </div>
    </div>
  );
}

function SetupBudgetScreen({ onComplete }: { onComplete: (id: string) => void }) {
  const [selectedPlan, setSelectedPlan] = useState<string>('balanced');
  const plan = BUDGET_TEMPLATES.find(t => t.id === selectedPlan) || BUDGET_TEMPLATES[0];

  return (
    <div className="flex-1 flex flex-col p-6 bg-gx-purple-dark relative overflow-hidden">
      <div className="ambient-glow w-64 h-64 bg-gx-pink/5 -top-20 -right-20"></div>
      
      <h2 className="text-2xl font-black mb-1 mt-4 text-white">Smart Budget Plans</h2>
      <p className="text-gray-300 mb-8 font-medium">Select a lifestyle that fits you.</p>

      <div className="flex gap-5 overflow-x-auto pb-10 scrollbar-hide snap-x relative z-10 -mx-6 px-6 touch-pan-x">
        {BUDGET_TEMPLATES.map((t) => (
          <motion.div
            key={t.id}
            whileTap={{ scale: 0.96 }}
            onClick={() => setSelectedPlan(t.id)}
            className={`flex-shrink-0 w-[280px] snap-center p-8 rounded-[44px] border transition-all cursor-pointer flex flex-col items-start gap-5 relative overflow-hidden ${
              selectedPlan === t.id
                ? 'border-gx-pink bg-white shadow-[0_20px_50px_rgba(255,0,255,0.15)] scale-[1.02] z-20'
                : 'border-white/10 bg-gx-purple-mid opacity-50 hover:opacity-80'
            }`}
          >
            {selectedPlan === t.id && (
              <motion.div 
                layoutId="selection-glow"
                className="absolute inset-0 bg-gx-pink/5 pointer-events-none"
              />
            )}
            <span className="text-5xl mb-2 drop-shadow-lg">{t.icon}</span>
            <div>
              <h3 className={`font-black text-xl tracking-tight leading-tight ${selectedPlan === t.id ? 'text-gx-purple-dark' : 'text-white'}`}>{t.name}</h3>
              <p className={`text-[13px] mt-2 font-bold leading-relaxed ${selectedPlan === t.id ? 'text-gray-500' : 'text-gray-400'}`}>
                {t.description}
              </p>
            </div>
            <div className="mt-auto space-y-2.5 w-full">
              <div className={`text-[14px] font-black ${selectedPlan === t.id ? 'text-gx-purple-dark' : 'text-white'}`}>
                RM {t.totalSafeDaily} / day
              </div>
              <div className="h-1 w-12 bg-gx-pink/20 rounded-full" />
              <div className={`text-[12px] font-black italic ${selectedPlan === t.id ? 'text-gx-pink drop-shadow-sm' : 'text-gx-pink/60'}`}>
                RM {t.estimatedSavingsRange} savings / mo
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto pr-1 space-y-6 relative z-10 mt-6 scrollbar-hide">
        <div className="gx-card !p-8 bg-gx-purple-mid border border-white/5 shadow-xl">
           <div className="flex justify-between items-center mb-10">
              <h4 className="text-[13px] font-black text-white tracking-tight">Your daily safe spend</h4>
              <div className="px-4 py-1.5 bg-gx-pink/10 rounded-full border border-gx-pink/20">
                <span className="text-[10px] font-black text-gx-pink tracking-tight italic">Recommended Plan</span>
              </div>
           </div>
           
           <div className="flex flex-col items-center mb-12">
              <h3 className="text-5xl font-black text-white tracking-tighter mb-2 italic">RM {plan.totalSafeDaily}</h3>
              <p className="text-gray-400 font-bold text-[11px] tracking-tight italic">Daily allocation</p>
           </div>

           <div className="space-y-6">
              <p className="text-[11px] font-black text-gray-500 tracking-[3px] mb-4">Category breakdown</p>
              {Object.entries(plan.categories).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-xl shadow-inner border border-white/5">
                      {value.emoji}
                    </div>
                    <span className="text-[14px] font-bold text-white capitalize">{key}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-[15px] font-black text-white leading-none">RM {value.daily} / day</p>
                    <p className="text-[11px] font-bold text-gray-400 mt-1 italic tracking-tight">RM {value.monthly} / month</p>
                  </div>
                </div>
              ))}
           </div>

           <div className="mt-10 pt-10 border-t border-white/5">
              <div className="bg-gx-pink/5 rounded-[32px] p-8 border border-gx-pink/10 flex flex-col items-center text-center">
                 <p className="text-gray-400 font-bold text-[11px] tracking-[3px] mb-3 italic">Estimated monthly savings</p>
                 <h4 className="text-3xl font-black text-gx-pink mb-4 tracking-tighter italic drop-shadow-[0_0_15px_rgba(255,0,255,0.2)]">💰 {plan.estimatedSavingsRange} / mo</h4>
                 <p className="text-[12px] text-gray-400 leading-relaxed max-w-[220px] font-medium italic">
                    "If you stay within this plan, you may save this amount monthly."
                 </p>
              </div>
           </div>
        </div>

        <div className="p-8 bg-emerald-500/5 rounded-[40px] border border-dashed border-emerald-500/20 flex flex-col gap-4">
           <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
               <TrendingUp size={20} />
             </div>
             <p className="text-[11px] font-black text-emerald-500 tracking-[3px] italic">Financial impact</p>
           </div>
           <p className="text-[14px] font-bold text-emerald-100 italic leading-relaxed tracking-tight">
             "{plan.impactInsight}"
           </p>
           <p className="text-[11px] text-emerald-400/60 font-medium">
             Based on your spending habits and selected plan.
           </p>
        </div>
      </div>

      <div className="pt-8 relative z-10">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={() => onComplete(selectedPlan)}
          className="gx-neon-button w-full py-6 text-sm tracking-widest uppercase font-black"
        >
          Activate {plan.name}
        </motion.button>
      </div>
    </div>
  );
}

function DashboardView({ user, setView }: { user: UserState, setView: (v: View) => void }) {
  const safeSpentPercent = (user.todaySpent / user.dailyBudget) * 100;
  const selectedTemplate = BUDGET_TEMPLATES.find(t => t.id === user.activeTemplate) || BUDGET_TEMPLATES[0];
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 pt-10 pb-6"
    >
      {/* Status Bar */}
      <div className="flex items-center justify-between px-2">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.4)]"></div>
          <span className="text-[11px] font-bold text-gray-300 tracking-tight">Smart budget active</span>
        </div>
        <div className="flex items-center gap-2 bg-gx-pink/10 px-3 py-1 rounded-full border border-gx-pink/20">
          <span className="text-[10px] font-black text-gx-pink tracking-tight italic">{selectedTemplate.name} mode</span>
        </div>
      </div>

      {/* Main Safe Spend Card */}
      <div className="bg-white rounded-[44px] relative overflow-hidden flex flex-col items-center py-12 shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gx-pink/5 rounded-full -mt-20 -mr-20 blur-3xl"></div>
        
        {/* Progress Circle Container */}
        <div className="relative w-48 h-48 flex items-center justify-center">
          <svg className="absolute inset-0 w-full h-full -rotate-90">
            <circle cx="96" cy="96" r="88" className="fill-none stroke-gray-100" strokeWidth="12" />
            <motion.circle 
              cx="96" cy="96" r="88" 
              className="fill-none stroke-gx-pink" 
              strokeWidth="12" 
              strokeDasharray={552}
              strokeDashoffset={552 - (552 * Math.min(100, Math.max(0, 100 - safeSpentPercent))) / 100}
              strokeLinecap="round"
              transition={{ duration: 1.5, ease: "easeOut" }}
            />
          </svg>
          <div className="flex flex-col items-center">
            <span className="text-[11px] font-bold text-gray-400 tracking-wider mb-1">Daily safe spend</span>
            <span className="text-5xl font-black text-gx-purple-dark italic tracking-tighter drop-shadow-sm">RM {(user.dailyBudget - user.todaySpent).toFixed(0)}</span>
            <span className="text-[12px] text-gray-500 font-bold mt-1 tracking-tight">Remaining today</span>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-8 w-full px-6 border-t border-gray-100 pt-8">
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-400 mb-1">Daily limit</p>
            <p className="text-lg font-black text-gx-purple-dark">RM {user.dailyBudget.toFixed(0)}</p>
          </div>
          <div className="text-center border-l border-gray-100">
            <p className="text-[10px] font-bold text-gray-400 mb-1">Total spent</p>
            <p className="text-lg font-black text-gx-pink">RM {user.todaySpent.toFixed(0)}</p>
          </div>
        </div>
      </div>

      {/* Category Limits */}
      <div className="space-y-4">
        <h4 className="text-[14px] font-black text-white tracking-tight px-2 mb-4">Daily category breakdown</h4>
        <div className="grid grid-cols-1 gap-3">
          {Object.entries(selectedTemplate.categories).map(([key, value]) => {
            const spent = (user.categorySpending as any)[key] || 0;
            const percent = Math.min(100, (spent / value.daily) * 100);
            return (
              <div key={key} className="gx-card !p-5 flex items-center gap-5 border-white/5 hover:bg-white/5 transition-all group">
                <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-3xl shadow-inner border border-white/5">
                  {value.emoji}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-end mb-3">
                    <span className="text-[14px] font-black text-white tracking-tight capitalize">{key}</span>
                    <div className="text-right">
                      <div className="flex items-baseline justify-end gap-1">
                        <span className="text-base font-black text-white leading-none">RM {spent.toFixed(0)}</span>
                        <span className="text-[11px] font-medium text-gray-400">/ Day {value.daily}</span>
                      </div>
                      <p className="text-[10px] font-bold text-gray-500 mt-1 italic">RM {value.monthly} / month limit</p>
                    </div>
                  </div>
                  <div className="h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${percent}%` }}
                      className={`h-full transition-colors duration-700 ${percent > 90 ? 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]' : 'bg-gx-pink shadow-[0_0_8px_rgba(255,0,255,0.4)]'}`} 
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Featured Goal */}
      <div className="gx-card !p-6 bg-white border-transparent shadow-xl">
        <div className="flex justify-between items-center mb-6">
           <span className="text-[12px] font-bold text-gray-400 tracking-tight">Active saving goal</span>
           <button onClick={() => setView('goals')} className="text-[12px] font-bold text-gx-pink italic underline decoration-gx-pink/20">Manage goals</button>
        </div>
        <div className="flex items-center gap-5 mb-6">
          <div className="w-14 h-14 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-center text-3xl shadow-sm">✈️</div>
          <div>
            <h4 className="font-black text-lg text-gx-purple-dark tracking-tight leading-none">Japan Trip Fund</h4>
            <p className="text-[13px] text-gray-400 font-bold mt-1.5 font-mono">RM 1,200 of RM 5,000</p>
          </div>
        </div>
        <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden border border-gray-100">
          <div className="h-full bg-gx-pink w-[65%] rounded-full shadow-[0_0_8px_rgba(255,0,255,0.2)]" />
        </div>
      </div>

      {/* Smart Habits Preview - Clean white cards */}
      <div className="space-y-4 mt-6">
        <h4 className="text-[12px] font-bold text-gray-400 italic px-2">Passion saving habits</h4>
        <div className="space-y-3">
          {user.smartHabits.slice(0, 2).map(habit => (
            <div key={habit.id} className="bg-white rounded-[32px] !p-5 flex items-center justify-between border border-transparent hover:border-gray-100 transition-all shadow-sm">
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center bg-gray-50 border border-gray-100 text-gx-pink">
                  <habit.icon size={22} strokeWidth={3} />
                </div>
                <div>
                  <p className="text-sm font-black text-gx-purple-dark leading-tight">{habit.name}</p>
                  <p className="text-[11px] text-gray-500 font-bold mt-1">Target: RM{habit.dailyTarget} daily</p>
                </div>
              </div>
              <div className="text-emerald-500 font-black text-[10px] bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100 italic">
                Active
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function GoalsView({ user }: { user: UserState }) {
  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pt-10 pb-6">
      <div className="flex justify-between items-center px-2">
        <div className="flex flex-col">
          <h3 className="text-2xl font-black text-white tracking-tight">Financial Dreams</h3>
          <p className="text-[11px] text-gray-400 font-bold tracking-tight mt-1 italic">Growth tracking active</p>
        </div>
        <motion.button 
          whileTap={{ scale: 0.9 }}
          className="w-14 h-14 rounded-2xl bg-gx-pink text-white flex items-center justify-center shadow-lg active:scale-95 transition-all shadow-gx-pink/20"
        >
          <Plus size={28}/>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {user.goals.map((goal) => (
          <div key={goal.id} className="bg-gx-purple-mid rounded-[40px] p-8 border border-white/5 hover:bg-white/5 transition-all shadow-xl">
            <div className="flex justify-between items-start mb-6">
              <div className="w-16 h-16 rounded-[28px] bg-white/5 border border-white/10 flex items-center justify-center text-4xl shadow-inner">
                {goal.icon}
              </div>
              <div className="text-right">
                <p className="text-[11px] font-bold text-gray-400 mb-1">Target amount</p>
                <p className="text-xl font-black text-white tracking-tight">RM {goal.targetAmount.toLocaleString()}</p>
              </div>
            </div>
            
            <div className="flex justify-between items-end mb-3">
              <h4 className="font-black text-lg text-white tracking-tight">{goal.name}</h4>
              <span className="text-gx-pink font-black text-lg tracking-tight italic">RM {goal.currentAmount.toLocaleString()}</span>
            </div>
            
            <div className="w-full h-3 bg-white/5 rounded-full overflow-hidden mb-6 border border-white/5">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: `${(goal.currentAmount / goal.targetAmount) * 100}%` }}
                 className="h-full bg-gx-pink rounded-full shadow-[0_0_15px_rgba(235,0,255,0.3)]"
               />
            </div>
            
            <div className="flex justify-between items-center text-[12px] font-bold text-gray-400">
               <span className="flex items-center gap-1.5"><Target size={14} className="text-gx-pink" /> {Math.round((goal.currentAmount / goal.targetAmount) * 100)}% reached</span>
               <span className="text-emerald-400 italic">On track ✨</span>
            </div>
          </div>
        ))}

        <button className="bg-white/5 border-2 border-dashed border-white/10 rounded-[44px] p-10 flex flex-col items-center justify-center text-gray-400 gap-4 hover:border-white/20 transition-all group">
          <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Plus size={32} />
          </div>
          <span className="text-sm font-bold tracking-tight">Add a new dream</span>
        </button>
      </div>
    </motion.div>
  );
}

function SavingsView({ user, setUser, setView }: { user: UserState, setUser: (u: UserState) => void, setView: (v: View) => void }) {
  const [savingAnimation, setSavingAnimation] = useState(false);

  const triggerManualSave = () => {
    setSavingAnimation(true);
    setTimeout(() => {
      setSavingAnimation(false);
      setUser({ ...user, totalSaved: user.totalSaved + 5, balance: user.balance - 5 });
    }, 2000);
  };

  const totalSavedValue = user.goals.reduce((acc, g) => acc + g.currentAmount, 0) + user.totalSaved;

  return (
    <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6 pt-10 pb-6">
      <div className="px-2 mb-2">
        <h3 className="text-2xl font-black text-white tracking-tight">Growth Center</h3>
        <p className="text-[11px] text-gray-400 font-bold tracking-tight mt-1 italic">Smart financial insights</p>
      </div>

      {/* Main Totals Card */}
      <div className="bg-white rounded-[44px] p-10 flex flex-col items-center text-center relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 left-0 w-32 h-32 bg-gx-pink/5 -mt-8 -ml-8 rounded-full blur-2xl"></div>
        <span className="text-[12px] font-bold text-gray-400 mb-4 tracking-tight">Total net worth</span>
        <h2 className="text-5xl font-black text-gx-purple-dark italic tracking-tighter drop-shadow-sm mb-4">RM {totalSavedValue.toLocaleString()}</h2>
        <div className="px-4 py-1.5 bg-emerald-500/10 rounded-full border border-emerald-100 flex items-center gap-2">
          <TrendingUp size={14} className="text-emerald-500" />
          <span className="text-[11px] font-bold text-emerald-600 tracking-tight">+RM 120.50 this week</span>
        </div>
      </div>

      {/* Control Toggles */}
      <div className="space-y-3">
        <h4 className="text-[11px] font-bold text-gray-400 px-2 mb-2 italic">Smart automations</h4>
        <div className="space-y-3">
          <div className="gx-card !p-6 flex items-center justify-between border-white/5 bg-white/5 transition-all">
             <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white">
                   <Zap size={22} />
                </div>
                <div>
                   <h5 className="text-sm font-black text-white tracking-tight">Auto-save daily</h5>
                   <p className="text-[11px] text-gray-400 font-bold">RM 1.00 daily contribution</p>
                </div>
             </div>
             <button 
                onClick={() => setUser({...user, autoSaveEnabled: !user.autoSaveEnabled})}
                className={`w-14 h-8 rounded-full relative p-1 cursor-pointer transition-colors ${user.autoSaveEnabled ? 'bg-gx-pink' : 'bg-white/10'}`}
             >
                <motion.div 
                  animate={{ x: user.autoSaveEnabled ? 24 : 0 }}
                  className="w-6 h-6 bg-white rounded-full shadow-md"
                ></motion.div>
             </button>
          </div>

          <div className="gx-card !p-6 flex items-center justify-between border-white/5 bg-white/5 transition-all">
             <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-white">
                   <Plus size={22} />
                </div>
                <div>
                   <h5 className="text-sm font-black text-white tracking-tight">Round-up change</h5>
                   <p className="text-[11px] text-gray-400 font-bold">Invest spare change daily</p>
                </div>
             </div>
             <button 
                onClick={() => setUser({...user, roundUpEnabled: !user.roundUpEnabled})}
                className={`w-14 h-8 rounded-full relative p-1 cursor-pointer transition-colors ${user.roundUpEnabled ? 'bg-gx-pink' : 'bg-white/10'}`}
             >
                <motion.div 
                  animate={{ x: user.roundUpEnabled ? 24 : 0 }}
                  className="w-6 h-6 bg-white rounded-full shadow-md"
                ></motion.div>
             </button>
          </div>
        </div>
      </div>

      <div className="pt-4">
        <motion.button
          disabled={savingAnimation}
          whileTap={{ scale: 0.98 }}
          onClick={triggerManualSave}
          className="w-full py-6 rounded-[44px] bg-gx-purple-mid border border-white/5 text-white flex flex-col items-center justify-center gap-1 relative overflow-hidden group shadow-2xl hover:bg-white/5 transition-all"
        >
          <AnimatePresence mode="wait">
            {savingAnimation ? (
              <motion.div 
                key="animating"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-3"
              >
                <div className="w-5 h-5 border-2 border-gx-pink border-t-transparent rounded-full animate-spin"></div>
                <span className="text-sm font-bold italic">Processing growth...</span>
              </motion.div>
            ) : (
              <motion.div 
                key="idle"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex flex-col items-center"
              >
                <span className="text-[10px] font-bold text-gray-500 tracking-[4px] uppercase mb-1">Instant Boost</span>
                <span className="text-base font-black tracking-tight flex items-center gap-2">Add RM 5 to savings <TrendingUp size={16} className="text-gx-pink" /></span>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.button>
      </div>

      {/* Liquidity Clarification */}
      <div className="gx-card !p-6 border-white/5 bg-white/5 mt-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-10 h-10 bg-yellow-500/10 rounded-xl flex items-center justify-center text-yellow-500">
            <Lock size={20} />
          </div>
          <div>
            <h5 className="text-sm font-black text-white tracking-tight">Protected status</h5>
            <p className="text-[11px] text-gray-400 font-bold">This money is not for daily use</p>
          </div>
        </div>
        <p className="text-[12px] text-gray-400 leading-relaxed font-medium italic mb-6">
          "It's your money, but we've placed it in this growth hub to protect your dreams (like your Japan Trip). Accessing it is possible, but we encourage leaving it to grow."
        </p>
        <button 
          onClick={() => alert("Withdrawal requested. Remember, using these funds will delay your 'Japan Trip' by approximately 2 weeks. Would you like to proceed anyway?")}
          className="text-[11px] font-black text-gray-500 uppercase tracking-widest hover:text-white transition-colors"
        >
          Withdraw funds
        </button>
      </div>
    </motion.div>
  );
}

function SummaryView({ user }: { user: UserState }) {
  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pt-10 pb-12">
      <div className="px-2">
        <h3 className="text-2xl font-black text-white px-2 tracking-tight">Growth Hub</h3>
        <p className="text-[11px] text-gray-400 font-bold tracking-tight mt-1 px-2 italic">Smart lifestyle analysis</p>
      </div>

      <div className="bg-gx-purple-mid rounded-[44px] p-10 flex flex-col items-center relative overflow-hidden group border border-white/5 shadow-xl">
        <div className="ambient-glow w-48 h-48 bg-emerald-500/5 -top-24 -right-24 blur-3xl opacity-30"></div>
        <div className="flex flex-col items-center py-6 relative z-10 w-full text-center">
           <div className="relative w-40 h-40 mb-10 flex items-center justify-center">
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-6 h-20 bg-white/5 rounded-full" />
              <motion.div 
                initial={{ scale: 0 }} animate={{ scale: 1 }}
                className="absolute top-6 left-1/2 -translate-x-1/2 w-24 h-24 bg-emerald-500/40 rounded-full blur-xl" 
              />
              <div className="w-20 h-20 bg-emerald-500 rounded-[32px] flex items-center justify-center text-white shadow-[0_10px_25px_rgba(16,185,129,0.3)]">
                <CheckCircle2 size={40} strokeWidth={3} />
              </div>
           </div>
           <h4 className="font-black text-white text-2xl tracking-tight leading-none mb-4">Financial resilience</h4>
           <div className="px-5 py-1.5 bg-emerald-500/10 rounded-full border border-emerald-500/20">
              <span className="text-[10px] text-emerald-400 uppercase font-black tracking-widest italic">Tier 4 stability active</span>
           </div>
        </div>
        <p className="text-[14px] font-bold text-center text-gray-300 italic px-4 leading-relaxed relative z-10 mt-6">
          "Your habits are blossoming. You're saving an extra <span className="text-gx-pink font-black drop-shadow-[0_0_10px_rgba(255,0,255,0.3)]">RM 240 / month</span> compared to the last period!"
        </p>
      </div>

      <div className="space-y-4 px-1">
          <div className="bg-white rounded-[40px] p-8 border border-white/5 relative overflow-hidden shadow-lg">
            <h5 className="font-black text-[12px] text-rose-500 mb-6 flex items-center gap-2 tracking-[2px] uppercase">
              <AlertCircle size={16} /> Action required
            </h5>
            <p className="text-[15px] text-gx-purple-dark font-bold leading-relaxed mb-8">
              "Late-night spending (11PM–3AM) is your biggest leakage. Saving this could reach your <b className="text-gx-pink underline decoration-gx-pink/30 font-black italic">Japan Trip</b> 3 months faster."
            </p>
            <div className="space-y-4">
              <div className="flex justify-between items-end text-[11px] font-bold text-gray-400 capitalize">
                <span>Monthly leakage estimate</span>
                <span className="text-rose-500 font-black text-lg">RM 450.00</span>
              </div>
              <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden border border-gray-100">
                <div className="h-full bg-rose-500 w-[75%] shadow-[0_0_10px_rgba(244,63,94,0.4)]" />
              </div>
            </div>
          </div>

          <div className="bg-gx-purple-mid rounded-[40px] p-8 border border-white/5 shadow-lg">
             <h5 className="font-bold text-[12px] text-gray-400 mb-8 tracking-tight italic">Growth velocity</h5>
             <div className="h-40 flex items-end justify-between gap-4 px-1">
                {[45, 60, 35, 90, 55, 75, 40].map((h, i) => (
                   <div key={i} className="flex-1 flex flex-col items-center gap-4">
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      className={`w-full rounded-t-xl transition-all duration-500 ${h > 70 ? 'bg-gx-pink shadow-[0_0_10px_rgba(255,0,255,0.3)]' : 'bg-white/10'}`}
                    />
                    <span className="text-[9px] font-bold text-gray-500 tracking-tighter">W{i+1}</span>
                  </div>
                ))}
             </div>
          </div>
      </div>
    </motion.div>
  );
}

function RewardsView({ user }: { user: UserState }) {
  const [spinning, setSpinning] = useState(false);
  const [won, setWon] = useState<string | null>(null);

  const spin = () => {
    setSpinning(true);
    setWon(null);
    setTimeout(() => {
      setSpinning(false);
      setWon('RM 5 Cashback Voucher');
    }, 2000);
  };

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6 pt-10 pb-6">
      <div className="flex flex-col">
        <h3 className="text-2xl font-black text-white px-2 tracking-tight">Consistency Perks</h3>
        <p className="text-[11px] text-gray-400 font-bold tracking-tight mt-1 px-2 italic">Rewards for your habits</p>
      </div>

      {/* Streak Tracker */}
      <div className="bg-white rounded-[44px] p-10 flex flex-col items-center relative overflow-hidden group shadow-2xl">
        <div className="ambient-glow w-48 h-48 bg-gx-orange/10 -top-24 -left-24 opacity-30"></div>
        <div className="relative mb-8 scale-110">
           <Zap size={72} className="text-gx-orange drop-shadow-[0_0_15px_rgba(255,125,0,0.4)]" fill="currentColor" />
           <div className="absolute inset-0 flex items-center justify-center pt-2">
              <span className="text-white font-black text-3xl drop-shadow-lg">{user.streak}</span>
           </div>
        </div>
        <h4 className="font-black text-2xl text-gx-purple-dark tracking-tight">Day {user.streak} streak</h4>
        <p className="text-center text-[13px] text-gray-500 mt-4 leading-relaxed px-4 font-bold italic">
          "Save at least RM1 every day to keep your streak and unlock weekly rewards!"
        </p>
      </div>

      {/* Lucky Draw Section */}
      <div className="bg-gx-purple-mid rounded-[44px] p-10 text-white relative overflow-hidden shadow-2xl border border-white/5">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gx-pink/5 rounded-full blur-2xl"></div>

        <div className="relative z-10 flex flex-col items-center">
          <h4 className="text-2xl font-black mb-3 italic tracking-tight">Weekly lucky draw</h4>
          <div className="px-5 py-1.5 bg-gx-pink/10 rounded-full border border-gx-pink/20 mb-12">
            <span className="text-[10px] text-gx-pink uppercase font-black tracking-widest italic">Ahmad's status: Eligible</span>
          </div>

          <AnimatePresence>
            {won && (
              <motion.div 
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[32px] p-8 mb-10 w-full text-center shadow-xl"
              >
                <div className="w-16 h-16 bg-white/5 rounded-2xl mx-auto flex items-center justify-center text-gx-pink mb-4 shadow-lg border border-white/10">
                  <Award size={36} />
                </div>
                <h5 className="font-black text-xl text-white">You won!</h5>
                <p className="text-base font-black text-gx-pink mt-1 italic tracking-tight">{won}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <motion.button 
            disabled={spinning}
            whileTap={{ scale: 0.98 }}
            onClick={spin}
            className={`gx-neon-button w-full py-6 text-sm tracking-widest uppercase font-black transition-all ${
              spinning ? 'opacity-50 pointer-events-none' : ''
            }`}
          >
            {spinning ? 'Drawing rewards...' : 'Spin my rewards'}
          </motion.button>
        </div>
      </div>
      {/* Available Rewards */}
      <div className="pb-8">
        <h4 className="text-[12px] font-bold text-gray-500 px-2 mb-4 italic mt-4 tracking-tight">Your reward vault</h4>
        <div className="space-y-4">
          <RewardCard name="GrabFood RM10 Off" icon={Truck} active />
          <RewardCard name="GXBank RM5 Cashback" icon={CheckCircle2} active={false} locked />
          <RewardCard name="Zalora 20% Voucher" icon={ShoppingBag} active />
        </div>
      </div>
    </motion.div>
  );
}

function RewardCard({ name, icon: Icon, active, locked }: { name: string, icon: any, active: boolean, locked?: boolean }) {
  return (
    <div className={`rounded-[32px] p-6 flex items-center justify-between transition-all border ${locked ? 'opacity-40 grayscale blur-[0.5px] pointer-events-none bg-white/5 border-white/5' : 'bg-gx-purple-mid border-white/5 hover:border-gx-pink/20'}`}>
      <div className="flex items-center gap-5">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ${active ? 'bg-white shadow-[0_4px_15px_rgba(0,0,0,0.1)] border-white text-gx-pink shadow-sm' : 'bg-white/5 border-white/5 text-gray-500'}`}>
          <Icon size={26} strokeWidth={active ? 3 : 2} />
        </div>
        <div>
          <p className="font-black text-[15px] text-white tracking-tight">{name}</p>
          <p className="text-[11px] text-gray-400 font-bold mt-1 tracking-tight italic">{locked ? 'Unlock at 15-day streak' : 'Expires in 4 days'}</p>
        </div>
      </div>
      <button className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-white text-gx-purple-dark shadow-[0_5px_15px_rgba(0,0,0,0.2)] active:scale-95' : 'bg-white/5 text-gray-500'}`}>
        {locked ? 'Locked' : 'Use'}
      </button>
    </div>
  );
}

function AlertScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex-1 flex flex-col p-6 bg-gx-purple-dark relative overflow-hidden">
      <div className="ambient-glow w-64 h-64 bg-rose-500/10 -top-20 -left-20 opacity-40"></div>
      
      <div className="mt-12 flex flex-col items-stretch relative z-10 px-2">
        <div className="gx-card !bg-white border-rose-100 border-[3px] p-10 rounded-[44px] mb-16 shadow-2xl">
          <div className="flex flex-col gap-8">
            <div className="w-20 h-20 bg-rose-50 rounded-3xl flex items-center justify-center text-5xl shadow-inner border border-rose-100">
              🛑
            </div>
            <div>
              <h3 className="text-3xl font-black text-rose-500 mb-4 tracking-tighter italic drop-shadow-sm">Slow down!</h3>
              <p className="text-[17px] text-gray-500 font-bold leading-relaxed tracking-tight">
                Ahmad, you've reached today's <span className="text-rose-500 underline decoration-2 font-black">shopping limit</span>. 
                <br/><br/>
                Every Ringgit saved now is one step closer to your <span className="text-gx-purple-dark font-black px-2 py-1 bg-gx-pink/10 rounded-lg ml-1 italic border border-gx-pink/20">Japan Trip 🇯🇵</span>
              </p>
            </div>
          </div>
        </div>
        
        <div className="w-full space-y-4">
          <motion.button 
            whileTap={{ scale: 0.98 }}
            onClick={onBack}
            className="gx-neon-button w-full py-6 text-base font-black tracking-widest uppercase shadow-rose-500/10"
          >
            Pause Purchase
          </motion.button>
          
          <motion.button 
            whileTap={{ scale: 0.98 }}
            onClick={onBack}
            className="w-full py-6 bg-white/5 border border-white/10 rounded-[32px] text-sm font-black text-white shadow-xl active:scale-95 transition-all"
          >
            Save my RM15 instead ✨
          </motion.button>
          
          <button 
            onClick={onBack}
            className="w-full py-4 text-gray-500 text-[12px] font-bold text-center hover:text-gray-300 transition-colors mt-4 italic"
          >
            Continue anyway (Not recommended)
          </button>
        </div>
      </div>
    </div>
  );
}
